package DAO;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import DTO.HabitacionDTO;

public class Habitacion {
	private Connection connection;
	
    public Habitacion(Connection connection) {
		this.connection = connection;
    }

    public void crearHabitacion(HabitacionDTO habitacion) throws SQLException {
    	String sql = "INSERT INTO habitaciones (numero, tipo, precio) VALUES (?, ?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
			pstmt.setString(1, habitacion.getNumero());
			pstmt.setString(2, habitacion.getTipo());
			pstmt.setDouble(3, habitacion.getPrecio());
			pstmt.executeUpdate();
		}
    }

    public List<HabitacionDTO> obtenerHabitaciones() throws SQLException {
    			String sql = "SELECT * FROM habitaciones";
		try (Statement stmt = connection.createStatement();
			 ResultSet rs = stmt.executeQuery(sql)) {
			List<HabitacionDTO> habitaciones = new ArrayList<>();
			while (rs.next()) { // Crear Habitacion con datos del DTO
				HabitacionDTO habitacion = new HabitacionDTO();
				habitacion.setNumero(rs.getString("numero"));
				habitacion.setTipo(rs.getString("tipo"));
				habitacion.setPrecio(rs.getDouble("precio"));
				habitaciones.add(habitacion);
			}
			return habitaciones;
		}    
    }
}
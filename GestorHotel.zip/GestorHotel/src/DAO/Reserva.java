package DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import DTO.ReservaDTO;

public class Reserva {
    private Connection connection;

    public Reserva(Connection connection) {
        this.connection = connection;
    }

    public void crearReserva(ReservaDTO nuevaReserva) throws SQLException {
        String sql = "INSERT INTO reservas(id_cliente, id_habitacion, fecha_entrada, fecha_salida) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, nuevaReserva.getIdCliente());
            pstmt.setInt(2, nuevaReserva.getIdHabitacion());
            pstmt.setDate(3, new java.sql.Date(nuevaReserva.getFechaEntrada().getTime()));
            pstmt.setDate(4, new java.sql.Date(nuevaReserva.getFechaSalida().getTime()));
            pstmt.executeUpdate();
        }   
    }

    public void modificarReserva(ReservaDTO reservaActualizada) throws SQLException {
        String sql = "UPDATE reservas SET id_cliente = ?, id_habitacion = ?, fecha_entrada = ?, fecha_salida = ? WHERE id_reserva = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, reservaActualizada.getIdCliente());
            pstmt.setInt(2, reservaActualizada.getIdHabitacion());
            pstmt.setDate(3, new java.sql.Date(reservaActualizada.getFechaEntrada().getTime()));
            pstmt.setDate(4, new java.sql.Date(reservaActualizada.getFechaSalida().getTime()));
            pstmt.setInt(5, reservaActualizada.getIdReserva());
            pstmt.executeUpdate();
        }
    }

    public boolean eliminarReserva(int idReserva) throws SQLException {
        String sql = "DELETE FROM reservas WHERE id_reserva = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, idReserva);
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        }
    }

    public List<ReservaDTO> listarTodasReservas() throws SQLException {
        List<ReservaDTO> reservas = new ArrayList<>();
        String sql = "SELECT * FROM reservas";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                ReservaDTO reserva = new ReservaDTO();
                reserva.setIdReserva(rs.getInt("id_reserva"));
                reserva.setIdCliente(rs.getInt("id_cliente"));
                reserva.setIdHabitacion(rs.getInt("id_habitacion"));
                reserva.setFechaEntrada(rs.getDate("fecha_entrada"));
                reserva.setFechaSalida(rs.getDate("fecha_salida"));
                reservas.add(reserva);
            }
        }
        return reservas;
    }
    
    public ReservaDTO buscarReservaPorId(int idReserva) throws SQLException {
        String sql = "SELECT * FROM reservas WHERE id_reserva = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, idReserva);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    ReservaDTO reserva = new ReservaDTO();
                    reserva.setIdReserva(rs.getInt("id_reserva"));
                    reserva.setIdCliente(rs.getInt("id_cliente"));
                    reserva.setIdHabitacion(rs.getInt("id_habitacion"));
                    reserva.setFechaEntrada(rs.getDate("fecha_entrada"));
                    reserva.setFechaSalida(rs.getDate("fecha_salida"));
                    return reserva;
                }
            }
        }
        return null;
    }
}
package DAO;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import DTO.ClienteDTO;

public class Cliente {
	private Connection connection;
	public Cliente(Connection connection) {
		this.connection = connection;
	}

	public void crearCliente(ClienteDTO cliente) throws SQLException {
		String sql = "INSERT INTO clientes (nombre, email) VALUES (?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
			pstmt.setString(1, cliente.getNombre());
			pstmt.setString(2, cliente.getEmail());
			pstmt.executeUpdate();
		}
    }

	public List<ClienteDTO> obtenerClientes() throws SQLException {
				String sql = "SELECT * FROM clientes";
		try (Statement stmt = connection.createStatement();
			 ResultSet rs = stmt.executeQuery(sql)) {
			List<ClienteDTO> clientes = new ArrayList<>();
			while (rs.next()) {
				ClienteDTO cliente = new ClienteDTO();
				cliente.setIdCliente(rs.getInt("id_cliente"));
				cliente.setNombre(rs.getString("nombre"));
				cliente.setEmail(rs.getString("email"));
				clientes.add(cliente);
			}
			return clientes;
		}
	}

	public ClienteDTO obtenerClientePorId(int id) throws SQLException {
		String sql = "SELECT * FROM clientes WHERE id_cliente = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
			pstmt.setInt(1, id);
			try (ResultSet rs = pstmt.executeQuery()) {
				if (rs.next()) {
					ClienteDTO cliente = new ClienteDTO();
					cliente.setIdCliente(rs.getInt("id_cliente"));
					cliente.setNombre(rs.getString("nombre"));
					cliente.setEmail(rs.getString("email"));
					return cliente;
				}
			}
		}
		return null;
    }
}
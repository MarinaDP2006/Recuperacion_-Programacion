package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class conexionBD {
	private static final String url = "jdbc:mysql://localhost:3306/hotel_gestionar";
	private static final String user= "root";
	private static final String password = "";
	
	public static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(url, getUser(), getPassword());
	}
	
	public String getUrl() {
		return url;
	}
	public String getUsuario() {
		return getUser();
	}

	public static String getPassword() {
		return password;
	}

	public static String getUser() {
		return user;
	}
}
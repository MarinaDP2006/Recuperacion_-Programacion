package dao;

import dto.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Conexion.conexionBD;

public class ClienteDAO {
    private Connection conexion;
    
    public ClienteDAO(Connection conexion) {
        this.conexion = conexion;
    }
    
	public void registrarCliente(Cliente cliente) {
        String sql = "INSERT INTO Cliente (id_cliente, nombre, email) VALUES (?, ?, ?)";
        
        try (Connection conn = conexionBD.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, cliente.getId_cliente());
            stmt.setString(2, cliente.getNombre());
            stmt.setString(3, cliente.getEmail());
            
            int filasAfectadas = stmt.executeUpdate();
            
            if (filasAfectadas > 0) {
                System.out.println("Cliente registrado exitosamente.");
            } else {
                System.out.println("No se pudo registrar el cliente.");
            }
            
        } catch (SQLException e) {
            System.err.println("Error al registrar cliente:");
            e.printStackTrace();
        }
    }

	public List<Cliente> mostrarClientes() { 
	    String sql = "SELECT * FROM cliente";
	    try (Connection conn = conexionBD.getConnection();
	         PreparedStatement stmt = conn.prepareStatement(sql)) {
	        
	        List<Cliente> clientes = new ArrayList<>();
	        ResultSet rs = stmt.executeQuery();
	        
	        while (rs.next()) {
	            String id_cliente = rs.getString("id_cliente");
	            String nombre = rs.getString("nombre");
	            String email = rs.getString("email");
	            
	            Cliente cliente = new Cliente(id_cliente, nombre, email);
	            clientes.add(cliente);
	        }
	        return clientes;
	    } catch (SQLException e) { 
	        System.err.println("Error al listar clientes:");
	        e.printStackTrace();
	        return new ArrayList<>();
	    }       
	}
}
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Conexion.conexionBD;
import dto.Habitacion;

public class HabitacionDAO {
    private Connection conexion;
    
    public HabitacionDAO(Connection conexion) {
        this.conexion = conexion;
    }
		
	public void verDisponibilidadHabitacion() {
	    String sql = "SELECT * FROM Habitacion WHERE disponible = true";

	    try (Connection conn = conexionBD.getConnection();
	         PreparedStatement stmt = conn.prepareStatement(sql)) {
	        ResultSet rs = stmt.executeQuery();

	        System.out.println("\n=== HABITACIONES DISPONIBLES ===");
	        boolean hayDisponibles = false;
	        
	        while (rs.next()) {
	            hayDisponibles = true;
	            System.out.println("Habitación ID: " + rs.getInt("id_habitacion"));
	            System.out.println("Tipo: " + rs.getString("tipo"));
	            System.out.println("Precio: " + rs.getDouble("precio"));
	        }

	        if (!hayDisponibles) {
	            System.out.println("No hay habitaciones disponibles en este momento.");
	        }

	    } catch (SQLException e) {
	        System.err.println("Error al consultar disponibilidad de habitación:");
	        e.printStackTrace();
	    }
	}
}
package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dto.Reserva;
import Conexion.conexionBD;

public class ReservaDAO {
    private Connection conexion;
    
    public ReservaDAO(Connection conexion) {
        this.conexion = conexion;
    }

    public void realizarReserva(Reserva reserva) {
        // Primero verificar disponibilidad
        String verificarDisponibilidad = "SELECT disponible FROM Habitacion WHERE id_habitacion = ?";
        String actualizarDisponibilidad = "UPDATE Habitacion SET disponible = false WHERE id_habitacion = ?";
        String sql = "INSERT INTO reserva (id_cliente, id_habitacion, fecha_entrada, fecha_salida) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = conexionBD.getConnection()) {
            conn.setAutoCommit(false); // Iniciar transacción
            
            // Verificar disponibilidad
            try (PreparedStatement stmt = conn.prepareStatement(verificarDisponibilidad)) {
                stmt.setInt(1, reserva.getIdHabitacion());
                ResultSet rs = stmt.executeQuery();
                
                if (!rs.next() || !rs.getBoolean("disponible")) {
                    System.out.println("La habitación no está disponible.");
                    return;
                }
            }
            
            // Actualizar disponibilidad
            try (PreparedStatement stmt = conn.prepareStatement(actualizarDisponibilidad)) {
                stmt.setInt(1, reserva.getIdHabitacion());
                stmt.executeUpdate();
            }
            
            // Crear reserva
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, reserva.getIdCliente());
                stmt.setInt(2, reserva.getIdHabitacion());
                stmt.setDate(3, Date.valueOf(reserva.getFechaEntrada()));
                stmt.setDate(4, Date.valueOf(reserva.getFechaSalida()));
                stmt.executeUpdate();
            }
            
            conn.commit();
            System.out.println("Reserva realizada exitosamente!");
            
        } catch (SQLException e) {
            System.err.println("Error al realizar reserva:");
            e.printStackTrace();
        }
    }
	public List<Reserva> consultarReservas() {
		List<Reserva> reservas = new ArrayList<>();
		String sql = "SELECT * FROM reserva";
		try (Connection conn = conexionBD.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery(sql);
			while (rs.next()) {
				Reserva reserva = new Reserva();
				reserva.setId(rs.getInt("id_reserva"));
				reserva.setIdCliente(rs.getInt("id_cliente"));
				reserva.setIdHabitacion(rs.getInt("id_habitacion"));
				reserva.setFechaEntrada(rs.getDate("fecha_entrada").toLocalDate());
				reserva.setFechaSalida(rs.getDate("fecha_salida").toLocalDate());
				reservas.add(reserva);
			}
		} catch (SQLException e) { e.printStackTrace();
		}
		return reservas;
	}

    public List<Reserva> listarTodas() {
        List<Reserva> reservas = new ArrayList<>();
        String sql = "SELECT * FROM reserva";
		try (Connection conn = conexionBD.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery(sql);
            while (rs.next()) {
                reservas.add(new Reserva(
                    rs.getInt("id_reserva"),
                    rs.getInt("id_cliente"),
                    rs.getInt("id_habitacion"),
                    rs.getDate("fecha_entrada").toLocalDate(),
                    rs.getDate("fecha_salida").toLocalDate()
                ));
            }
        } catch (SQLException e) { e.printStackTrace();
        }
        return reservas;
    }

    public void cancelarReserva(int idReserva) {
        String obtenerHabitacion = "SELECT id_habitacion FROM reserva WHERE id_reserva = ?";
        String liberarHabitacion = "UPDATE Habitacion SET disponible = true WHERE id_habitacion = ?";
        String eliminarReserva = "DELETE FROM reserva WHERE id_reserva = ?";
        
        try (Connection conn = conexionBD.getConnection()) {            
            int idHabitacion = -1;
            
            // Obtener ID de habitación
            try (PreparedStatement stmt = conn.prepareStatement(obtenerHabitacion)) {
                stmt.setInt(1, idReserva);
                ResultSet rs = stmt.executeQuery();
                
                if (rs.next()) {
                    idHabitacion = rs.getInt("id_habitacion");
                } else {
                    System.out.println("Reserva no encontrada.");
                    return;
                }
            }
            
            // Liberar habitación
           try (PreparedStatement stmt = conn.prepareStatement(liberarHabitacion)) {
                stmt.setInt(1, idHabitacion);
                stmt.executeUpdate();
            }
            
            // Eliminar reserva
            try (PreparedStatement stmt2 = conn.prepareStatement(eliminarReserva)) {
                stmt2.setInt(1, idReserva);
                stmt2.executeUpdate();
            }
            
            conn.commit();
            System.out.println("Reserva cancelada y habitación liberada exitosamente!");
        }    
    catch (SQLException e) {
			System.err.println("Error al cancelar reserva:");
			e.printStackTrace();
		}
}
	public void modificarReserva(Reserva reserva) {
		String sql = "UPDATE reserva SET id_cliente = ?, id_habitacion = ?, fecha_entrada = ?, fecha_salida = ? WHERE id_reserva = ?";
		try (Connection conn = conexionBD.getConnection();
			 PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setInt(1, reserva.getIdCliente());
			pstmt.setInt(2, reserva.getIdHabitacion());
			pstmt.setDate(3, Date.valueOf(reserva.getFechaEntrada()));
			pstmt.setDate(4, Date.valueOf(reserva.getFechaSalida()));
			pstmt.setInt(5, reserva.getId());
			pstmt.executeUpdate();
		} catch (SQLException e) { e.printStackTrace();
		}
	}
}
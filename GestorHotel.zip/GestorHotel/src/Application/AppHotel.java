package Application;
// Import SQL
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

// Import clase DAO
import DAO.Habitacion;
import DAO.Reserva;

import DTO.HabitacionDTO;
import DTO.ReservaDTO;

public class AppHotel {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion;
        
        // Onjeto conexion a la base de datos
        conexionBD.ConexBD conexion = new conexionBD.ConexBD();
        String url = conexion.getUrl();
        String user = conexion.getUser();
        String password = conexion.getPassword();
                
        try (Connection connection = DriverManager.getConnection(url, user, password)) {
            Reserva reservaDAO = new Reserva(connection);
            Habitacion habitacionDAO = new Habitacion(connection);
            
            do {
                System.out.println("\n=== Gestión de Hotel ===");
                System.out.println("1. Hacer una reserva de habitación");
                System.out.println("2. Ver reservas");
                System.out.println("3. Ver habitaciones disponibles");
                System.out.println("4. Modificar reserva");
                System.out.println("5. Cancelar reserva");
                System.out.println("6. Salir");
                System.out.print("\nSeleccione opción: ");
                opcion = sc.nextInt();
                sc.nextLine();

                switch (opcion) {
                    case 1:
                        // Hacer una reserva
                        System.out.print("ID Cliente: ");
                        int idCliente = sc.nextInt();
                        System.out.print("ID Habitación: ");
                        int idHabitacion = sc.nextInt();
                        System.out.print("Fecha Entrada (YYYY-MM-DD): ");
                        String fechaEntrada = sc.next();
                        System.out.print("Fecha Salida (YYYY-MM-DD): ");
                        String fechaSalida = sc.next();
                        
                        ReservaDTO nuevaReserva = new ReservaDTO();
              		    nuevaReserva.setIdCliente(idCliente);
                        System.out.println("Reserva creada con éxito.");
                        break;
                    case 2:
                        List<ReservaDTO> reserva = reservaDAO.listarTodasReservas();
                        for (ReservaDTO r : reserva) {
                            System.out.println("Reserva ID: " + r.getIdReserva() + ", Cliente ID: " + r.getIdCliente() + ", Habitación ID: " + r.getIdHabitacion());
                        }
                        break;
                    case 3:
                        List<HabitacionDTO> habitacion = habitacionDAO.obtenerHabitaciones();
                        for (HabitacionDTO h : habitacion) {
                            System.out.println("Habitación ID: " + h.getIdHabitacion() + ", Número: " + h.getNumero() + ", Tipo: " + h.getTipo() + ", Precio: " + h.getPrecio());
                        }
                        break;
                    case 4:
                        // Modificar reserva
                        System.out.print("ID Reserva a modificar: ");
                        int idReservaModificar = sc.nextInt();
                        System.out.print("Nueva Fecha Entrada (YYYY-MM-DD): ");
                        String nuevaFechaEntrada = sc.next();
                        System.out.print("Nueva Fecha Salida (YYYY-MM-DD): ");
                        String nuevaFechaSalida = sc.next();
                       
                        // Datos ReservaDTO
                        reservaDAO.modificarReserva(new ReservaDTO(idReservaModificar, 0, 0, Date.valueOf(nuevaFechaEntrada), Date.valueOf(nuevaFechaSalida)));
                        ReservaDTO reservaActualizada = new ReservaDTO();
                        reservaActualizada.setIdReserva(idReservaModificar);
                        System.out.println("Reserva modificada con éxito.");
                        break;
                    case 5:
                        // Cancelar reserva
                        System.out.print("ID Reserva a cancelar: ");
                        int idReservaCancelar = sc.nextInt();
                        reservaDAO.eliminarReserva(idReservaCancelar);
                        System.out.println("Reserva cancelada con éxito.");
                        break;
                    case 6:
                        System.out.println("Saliendo...");
                        break;
                    default:
                        System.out.println("Opción no válida.");
                }
            } while (opcion != 6);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
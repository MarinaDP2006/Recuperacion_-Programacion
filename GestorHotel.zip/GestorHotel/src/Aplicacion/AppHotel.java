package Aplicacion;

import dao.ClienteDAO;
import dao.HabitacionDAO;
import dao.ReservaDAO;
import dto.Cliente;
import dto.Habitacion;
import dto.Reserva;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.SQLException;

import Conexion.conexionBD;

public class AppHotel {
    public static void main(String[] args) {
        // Establecer conexión a la base de datos
        Connection conexion = null;
        try {
            conexion = conexionBD.getConnection();
            System.out.println("Conexión establecida con la base de datos");
        } catch (SQLException e) {
            System.err.println("Error al conectar con la base de datos:");
            e.printStackTrace();
            return;
        }

        ClienteDAO clienteDAO = new ClienteDAO(conexion);
        HabitacionDAO habitacionDAO = new HabitacionDAO(conexion);
        ReservaDAO reservaDAO = new ReservaDAO(conexion);
        
        Scanner sc = new Scanner(System.in);
        
        // Mostrar el menú
        int opcion;
        do {
            System.out.println("\n=== MENU HOTEL ===");
            System.out.println("1. Registrar Cliente");
            System.out.println("2. Ver habitaciones disponibles");
            System.out.println("3. Realizar Reserva");
            System.out.println("4. Consultar Reservas");
            System.out.println("5. Modificar Reserva");
            System.out.println("6. Cancelar Reserva");
            System.out.println("7. Ver clientes");
            System.out.println("8. Salir");
            System.out.print("\nSeleccione una opción: ");
            opcion = sc.nextInt();
            sc.nextLine(); 

            switch (opcion) {
                case 1:
                    System.out.println("Registrar Cliente");
                    System.out.print("ID Cliente: ");
                    String id_cliente = sc.nextLine();
                    System.out.print("Nombre: ");
                    String nombre = sc.nextLine();
                    System.out.print("Email: ");
                    String email = sc.nextLine();
                    Cliente cliente = new Cliente(id_cliente, nombre, email);
                    clienteDAO.registrarCliente(cliente);
                    break;

                case 2:
                	System.out.println("Habitaciones disponibles:");
                    habitacionDAO.verDisponibilidadHabitacion();
                    break;

                case 3:
                    System.out.println("Realizar Reserva");
                    System.out.print("ID cliente: ");
                    int idCliente = sc.nextInt();
                    System.out.print("ID habitación: ");
                    int id_Habitacion = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Fecha entrada (YYYY-MM-DD): ");
                    LocalDate fecha_entrada = LocalDate.parse(sc.nextLine());
                    System.out.print("Fecha salida (YYYY-MM-DD): ");
                    LocalDate fecha_salida = LocalDate.parse(sc.nextLine());

                    Reserva reserva = new Reserva();
                    reserva.setIdCliente(idCliente);
                    reserva.setIdHabitacion(id_Habitacion);
                    reserva.setFechaEntrada(fecha_entrada);
                    reserva.setFechaSalida(fecha_salida);
                    
                    reservaDAO.realizarReserva(reserva);
                    break;

                case 4:
                    List<Reserva> reservas = reservaDAO.listarTodas();
                    if (reservas.isEmpty()) {
                        System.out.println("No hay reservas");
                    } else {
                        for (Reserva r : reservas) {
                            System.out.println(r);
                        }
                    }
                    break;

                case 5:
                    System.out.print("ID reserva a modificar: ");
                    int idReserva = sc.nextInt();
                    sc.nextLine();
                    
                    System.out.print("Nuevo ID cliente: ");
                    int nuevoCliente = sc.nextInt();
                    System.out.print("Nuevo ID habitación: ");
                    int nuevaHabitacion = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Nueva fecha inicio (YYYY-MM-DD): ");
                    LocalDate nuevaEntrada = LocalDate.parse(sc.nextLine());
                    System.out.print("Nueva fecha fin (YYYY-MM-DD): ");
                    LocalDate nuevaSalida = LocalDate.parse(sc.nextLine());

                    Reserva reservaMod = new Reserva();
                    reservaMod.setId(idReserva);
                    reservaMod.setIdCliente(nuevoCliente);
                    reservaMod.setIdHabitacion(nuevaHabitacion);
                    reservaMod.setFechaEntrada(nuevaEntrada);
                    reservaMod.setFechaSalida(nuevaSalida);
                    
                    reservaDAO.modificarReserva(reservaMod);
                    System.out.println("Reserva modificada!");
                    break;

                case 6:
                    System.out.print("ID reserva a cancelar: ");
                    int idCancelar = sc.nextInt();
                    reservaDAO.cancelarReserva(idCancelar);
                    System.out.println("Reserva cancelada!");
                    break;
                case 7:
                    System.out.println("Lista de clientes actuales:");
                    List<Cliente> clientes = clienteDAO.mostrarClientes();
                    if (clientes.isEmpty()) {
                        System.out.println("No hay clientes registrados.");
                    } else {
                        for (Cliente c : clientes) {
                            System.out.println("- " + c);  
                        }
                    }
                    break;
                case 8:
                    System.out.println("Saliendo del sistema...");
                    break;
                    
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        } while (opcion != 8);
        
        sc.close();
        try {
            if (conexion != null) conexion.close();
        } catch (SQLException e) {
            System.err.println("Error al cerrar la conexión:");
            e.printStackTrace();
        }
    }
}
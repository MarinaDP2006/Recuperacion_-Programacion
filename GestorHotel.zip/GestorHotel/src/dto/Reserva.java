package dto;
import java.time.LocalDate;

public class Reserva{
    private int id;
    private int idCliente;
    private int idHabitacion;
    private LocalDate fechaEntrada;
    private LocalDate fechaSalida;

    public Reserva(int id, int idCliente, int idHabitacion, LocalDate fechaEntrada, LocalDate fechaSalida) {
        this.id = id;
        this.idCliente = idCliente;
        this.idHabitacion = idHabitacion;
        this.fechaEntrada = fechaEntrada;
        this.fechaSalida = fechaSalida;
    }

    public Reserva() {
    }

    public int getId() { return id; }
    public int getIdCliente() { return idCliente; }
    public int getIdHabitacion() { return idHabitacion; }
    public LocalDate getFechaEntrada() { return fechaEntrada; }
    public LocalDate getFechaSalida() { return fechaSalida; }

    public void setId(int id) { this.id = id; }
    public void setIdCliente(int idCliente) { this.idCliente = idCliente; }
    public void setIdHabitacion(int idHabitacion) { this.idHabitacion = idHabitacion; }
    public void setFechaEntrada(LocalDate fechaEntrada) { this.fechaEntrada = fechaEntrada; }
    public void setFechaSalida(LocalDate localDate) { this.fechaSalida = localDate; }  
    
    @Override
    public String toString() {
		return "\nReserva con identificacion " + id + ":" + 
				"\nId Cliente: " + idCliente +", Habitacion: " + idHabitacion +
				"\nEntrada: " + fechaEntrada + "\nSalida= " + fechaSalida;
	}
}  